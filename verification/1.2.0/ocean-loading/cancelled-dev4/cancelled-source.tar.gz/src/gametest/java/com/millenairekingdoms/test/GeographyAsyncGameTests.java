package com.millenairekingdoms.test;

import com.millenairekingdoms.atlas.geography.*;
import com.millenairekingdoms.network.ChronicleRequestPayload;
import com.mojang.authlib.GameProfile;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.*;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Deliberately stalls only the own-cache worker. Validated in-memory observations must still render progressively. */
@PrefixGameTestTemplate(false)
public final class GeographyAsyncGameTests {
    @GameTest(templateNamespace="millenairekingdoms_geography_tests",template="empty",batch="geography_async",timeoutTicks=1200)
    public static void slowDiskNeverBlocksPartialDisplayAndOnlyAcknowledgementAdvancesDurability(GameTestHelper h)throws Exception{
        var level=h.getLevel();var center=h.absolutePos(new BlockPos(2,1,2));
        for(int z=(center.getZ()>>4)-3;z<=(center.getZ()>>4)+3;z++)for(int x=(center.getX()>>4)-3;x<=(center.getX()>>4)+3;x++)level.getChunk(x,z);
        var observer=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"Async cartographer"));observer.setPos(center.getX()+.5,256,center.getZ()+.5);
        var field=GeographyService.class.getDeclaredField("MASK_IO");field.setAccessible(true);var executor=(ExecutorService)field.get(null);
        var entered=new CountDownLatch(1);var release=new CountDownLatch(1);var gate=executor.submit(()->{entered.countDown();try{release.await(20,TimeUnit.SECONDS);}catch(InterruptedException interrupted){Thread.currentThread().interrupt();}});
        var client=new GeographySnapshot();client.clear(level.dimension().location().toString());var viewport=GeographyViewport.around(center.getX(),center.getZ(),16);client.viewport(viewport);
        int[] phase={0};long[] first={0},started={System.nanoTime()};var session=UUID.randomUUID();
        h.succeedWhen(()->{
            h.assertTrue(entered.getCount()==0,"Controlled slow-disk gate is still waiting for prior bounded work");
            var request=ChronicleRequestPayload.geography(session,level.getGameTime(),client.after(),client.through(),viewport,client.stream());
            int before=level.getChunkSource().getLoadedChunksCount(),forced=level.getForcedChunks().size();var view=GeographyView.build(observer,request);
            if(phase[0]==0)GeographyService.observePlayers(level.getServer(),List.of(observer));
            h.assertTrue(before==level.getChunkSource().getLoadedChunksCount() && forced==level.getForcedChunks().size(),"Actual live acquisition/display query never loads or forces chunks");client.accept(view);
            if(phase[0]==0){
                h.assertTrue(client.size()>0,"Await first processed in-memory tile, independently of the blocked disk worker");
                h.assertTrue(!gate.isDone() && !Files.exists(GeographyService.directory(level,observer.getUUID()).resolve("index.dat")),"A valid visible observation precedes disk completion");
                h.assertTrue(view.getLong("durableRevision")==0 && view.getBoolean("pendingDisk"),"Ephemeral display revision never claims a durable root acknowledgement");
                var masks=new HashMap<GeographyTile.Position,GeographyTile>();client.tiles().forEach(t->masks.put(t.position(),t));var raster=GeographyRaster.build(masks,new GeographyRaster.View(center.getX(),center.getZ(),4,128,128));h.assertTrue(Arrays.stream(raster.ground()).anyMatch(color->color!=0) && client.at(center.getX()+512,center.getZ())==GeographyTile.UNKNOWN,"Completed masks render before unfinished regions; unknown geography remains unknown");
                first[0]=System.nanoTime()-started[0];System.out.println("GEOGRAPHY_PROGRESSIVE_SLOW_DISK first_display_ready_ms="+first[0]/1_000_000.0+" visible_tiles="+client.size()+" durable_revision=0 main_ns="+view.getCompound("metrics").getLong("mainNanos")+" graphics_verified=false");
                phase[0]=1;release.countDown();h.assertTrue(false,"Await real disk acknowledgement after progressive display");
            }
            h.assertTrue(GeographyService.ready(observer),"Pending valid observations are still draining to durable format1");
            var store=GeographyService.store(observer);h.assertTrue(store.size()>0 && store.revision()>0 && !store.query(0,Long.MAX_VALUE).tiles().isEmpty(),"The same actual observations also become durable after the worker resumes");
            h.assertTrue(GeographyService.lastWriteThread(observer).equals("Kingdoms geography writer"),"Disk commits are owned by the dedicated worker");
            System.out.println("GEOGRAPHY_PROGRESSIVE_SLOW_DISK_ACK visible_before_durable=true durable_revision="+store.revision()+" pending_cap="+GeographyService.MAX_PENDING_WRITES);
        });
    }
}
