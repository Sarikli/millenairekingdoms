package com.millenairekingdoms.test;

import com.millenairekingdoms.atlas.geography.*;
import com.millenairekingdoms.network.ChronicleRequestPayload;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.*;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@PrefixGameTestTemplate(false)
public final class GeographyProgressiveGameTests {
    private static final String NS="millenairekingdoms_geography_tests";
    private static String digest(byte[] bytes){try{return java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(bytes));}catch(Exception failure){throw new AssertionError(failure);}}
    private static byte[] mask(int value){var bytes=new byte[256];GeographyTile.set(bytes,0,0,value);return bytes;}
    private static CompoundTag page(GeographyWorkingSet set,long after,long through,GeographyViewport viewport){
        var p=set.page(after,through,viewport);var tag=new CompoundTag();tag.putString("mode","GEOGRAPHY");tag.putString("dimension","minecraft:overworld");tag.putUUID("stream",set.epoch());tag.putLong("durableRevision",0);tag.putBoolean("pendingDisk",true);tag.putBoolean("persistenceUnavailable",false);tag.putBoolean("pendingSamples",p.more());tag.putLong("watermark",p.watermark());tag.putLong("nextRevision",p.next());tag.putBoolean("more",p.more());tag.putBoolean("reset",p.reset());var list=new ListTag();for(var tile:p.tiles()){var row=new CompoundTag();row.putInt("x",tile.position().x());row.putInt("z",tile.position().z());row.putLong("revision",tile.revision());row.putByteArray("cells",tile.cells());list.add(row);}tag.put("geography",list);return tag;
    }
    @GameTest(templateNamespace=NS,template="empty")
    public static void viewportPagingShowsFarCachedTilesFirstAndRetainsEarlierRegionsOnPan(GameTestHelper h){
        var server=new GeographyWorkingSet();for(int x=0;x<130;x++)server.publish(new GeographyTile.Position(x,0),mask(GeographyTile.LAND),true);
        var viewport=GeographyViewport.around(129*32,0,1);var client=new GeographySnapshot();client.clear("minecraft:overworld");client.viewport(viewport);client.accept(page(server,0,Long.MAX_VALUE,viewport));
        h.assertTrue(client.at(129*32,0)==GeographyTile.LAND && client.size()<=2,"Viewport filtering returns the far authorized cached tile without downloading128 irrelevant older tiles");
        var near=GeographyViewport.around(0,0,1);client.viewport(near);client.accept(page(server,client.after(),client.through(),near));h.assertTrue(client.at(0,0)==GeographyTile.LAND && client.at(129*32,0)==GeographyTile.LAND,"Pan resets only its delivery cursor and retains valid cached regions");h.succeed();
    }
    @GameTest(templateNamespace=NS,template="empty")
    public static void displayStreamNeverAdvancesDurableAcknowledgementAndRejectsMalformedPartialPages(GameTestHelper h){
        var set=new GeographyWorkingSet();set.publish(new GeographyTile.Position(0,0),mask(GeographyTile.OCEAN),true);var client=new GeographySnapshot();client.accept(page(set,0,Long.MAX_VALUE,null));long before=client.changes();
        set.publish(new GeographyTile.Position(1,0),mask(GeographyTile.LAND),true);var broken=page(set,client.after(),client.through(),null);broken.getList("geography",10).getCompound(0).putByteArray("cells",new byte[255]);boolean refused=false;try{client.accept(broken);}catch(IllegalArgumentException expected){refused=true;}
        h.assertTrue(refused && client.changes()==before && client.size()==1 && client.at(0,0)==GeographyTile.OCEAN,"A malformed unfinished update cannot hide or partially replace an already valid visible tile");
        h.assertTrue(page(set,0,Long.MAX_VALUE,null).getLong("durableRevision")==0 && set.revision()>0,"Display sequence and disk acknowledgement are independent namespaces");h.succeed();
    }
    @GameTest(templateNamespace=NS,template="empty")
    public static void newStreamAcceptsLowRevisionsAndWarmHydrationCannotEraseFreshObservations(GameTestHelper h){
        var set=new GeographyWorkingSet();var pos=new GeographyTile.Position(0,0);set.publish(pos,mask(GeographyTile.OCEAN),true);set.publish(pos,mask(GeographyTile.LAND),false);h.assertTrue(set.tile(pos).at(0,0)==GeographyTile.OCEAN,"A delayed valid disk hydration fills unknown cells but never overwrites newer live observations");
        long version=set.revision();set.publish(pos,mask(GeographyTile.OCEAN),true);h.assertTrue(set.revision()==version,"An unchanged snapshot produces neither a new tile revision nor a redundant disk write");
        var client=new GeographySnapshot();client.accept(page(set,0,Long.MAX_VALUE,null));var newer=new GeographyWorkingSet();newer.publish(pos,mask(GeographyTile.LAND),true);client.accept(page(newer,0,Long.MAX_VALUE,null));h.assertTrue(client.at(0,0)==GeographyTile.LAND,"A restarted stream may reuse low numbers without being ignored as an old tile revision");h.succeed();
    }
    @GameTest(templateNamespace=NS,template="empty")
    public static void boundedIndependentPollerRecoversDroppedRepliesAndIgnoresSupersededViewports(GameTestHelper h){
        var poll=new GeographyPoller();poll.viewport(GeographyViewport.around(0,0,16),"minecraft:overworld",0);h.assertTrue(poll.due(0),"Cold open can request immediately");poll.sent(1,0);h.assertTrue(!poll.due(39) && poll.due(40),"A dropped response has a bounded40-tick timeout instead of indefinite Loading");poll.sent(2,40);poll.viewport(GeographyViewport.around(1000,0,16),"minecraft:overworld",41);h.assertTrue(!poll.accept(2) && !poll.due(41) && poll.due(44),"Pan ignores late replies and retains the4-tick request budget");poll.sent(3,44);h.assertTrue(poll.accept(3),"Current viewport response is accepted");poll.retry(44,1000000);h.assertTrue(!poll.due(83) && poll.due(84),"Server retry hints cannot suspend the lane indefinitely");h.succeed();
    }
    @GameTest(templateNamespace=NS,template="empty")
    public static void viewportPriorityIsBoundedWireDataAndNeverCarriesDiscoveryAuthority(GameTestHelper h){
        var viewport=GeographyViewport.around(-1000,2000,48);var request=ChronicleRequestPayload.geography(UUID.randomUUID(),2,0,Long.MAX_VALUE,viewport,Optional.of(UUID.randomUUID()));var buffer=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),h.getLevel().registryAccess());
        try{ChronicleRequestPayload.CODEC.encode(buffer,request);h.assertTrue(buffer.readableBytes()<160 && ChronicleRequestPayload.CODEC.decode(buffer).equals(request),"Viewport/stream roundtrip remains a small bounded read-only request");}finally{buffer.release();}
        boolean rejected=false;try{new GeographyViewport(Integer.MIN_VALUE,0,Integer.MAX_VALUE,1);}catch(IllegalArgumentException expected){rejected=true;}h.assertTrue(rejected,"Out-of-world priority bounds are refused without a world lookup");h.succeed();
    }

    @GameTest(templateNamespace=NS,template="empty",batch="geography_progressive_actual",timeoutTicks=12000)
    public static void actualCoastColdAndWarmOpenProgressivelyAndRestartHydratesWithoutTerrainReads(GameTestHelper h)throws Exception{
        var level=GeographyGameTests.noise(h);var marker=level.getServer().getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("progressive-ocean-restart.dat");
        boolean read="read".equals(System.getProperty("kingdoms.tests.persistence"));var saved=read?com.millenairekingdoms.history.HistoryFiles.read(marker):new CompoundTag();
        var coast=read?new net.minecraft.core.BlockPos(saved.getInt("x"),63,saved.getInt("z")):GeographyGameTests.coast(h,level);
        var owner=read?saved.getUUID("player"):UUID.randomUUID();var observer=new net.neoforged.neoforge.common.util.FakePlayer(level,new com.mojang.authlib.GameProfile(owner,"Progressive coast"));observer.setPos(coast.getX()+.5,256,coast.getZ()+.5);
        var viewport=GeographyViewport.around(coast.getX(),coast.getZ(),20);var client=new GeographySnapshot();client.clear(level.dimension().location().toString());client.viewport(viewport);
        long started=System.nanoTime();long[] first={-1};int[] phase={0};var connection=UUID.randomUUID();
        h.succeedWhen(()->{
            int before=level.getChunkSource().getLoadedChunksCount(),forced=level.getForcedChunks().size();
            var view=GeographyView.build(observer,ChronicleRequestPayload.geography(connection,level.getGameTime(),client.after(),client.through(),viewport,client.stream()));client.accept(view);
            if(!read && phase[0]==0)GeographyService.observePlayers(level.getServer(),List.of(observer));
            h.assertTrue(before==level.getChunkSource().getLoadedChunksCount() && forced==level.getForcedChunks().size(),"Cold/warm/restart live acquisition and display queries never request or force a chunk");
            if(client.size()>0 && first[0]<0)first[0]=System.nanoTime()-started;
            h.assertTrue(client.at(coast.getX(),coast.getZ())==GeographyTile.OCEAN,"Await actual coast observation or durable viewport hydration");
            var masks=new HashMap<GeographyTile.Position,GeographyTile>();client.tiles().forEach(t->masks.put(t.position(),t));h.assertTrue(GeographyRaster.coastEdges(masks,coast.getX(),coast.getZ())!=0,"Actual ocean and neighboring land retain their one-block coast in the progressive raster");
            if(read){
                h.assertTrue(GeographyService.ready(observer),"Restart hydration is still reading the old format1 index");var store=GeographyService.store(observer);String digest=digest(store.cells(GeographyTile.Position.at(coast.getX(),coast.getZ())));
                h.assertTrue(digest.equals(saved.getString("maskSha256")) && store.revision()==saved.getLong("revision"),"Separate JVM preserves the exact acknowledged masks/revision; display streams may have new low numbers");
                h.assertTrue(view.getCompound("metrics").getLong("capturedColumns")==0,"Cached restart display requires no new terrain snapshot");System.out.println("GEOGRAPHY_PROGRESSIVE_REOPEN first_display_ready_ms="+first[0]/1_000_000.0+" mask_sha256="+digest+" loaded="+before+" forced="+forced+" graphics_verified=false");return;
            }
            if(phase[0]==0){h.assertTrue(client.availableComplete(),"Already visible tiles remain available while the rest of the authorized viewport completes");phase[0]=1;}
            h.assertTrue(GeographyService.ready(observer),"Available viewport is visible; waiting separately for restart durability");
            long captured=view.getCompound("metrics").getLong("capturedColumns");var warm=new GeographySnapshot();warm.clear(level.dimension().location().toString());warm.viewport(viewport);var warmed=GeographyView.build(observer,ChronicleRequestPayload.geography(connection,level.getGameTime()+1,0,Long.MAX_VALUE,viewport,Optional.empty()));warm.accept(warmed);
            h.assertTrue(warm.at(coast.getX(),coast.getZ())==GeographyTile.OCEAN && warmed.getCompound("metrics").getLong("capturedColumns")==captured,"Warm open immediately reuses completed tiles without rescanning the terrain");
            var store=GeographyService.store(observer);String digest=digest(store.cells(GeographyTile.Position.at(coast.getX(),coast.getZ())));var record=new CompoundTag();record.putUUID("player",owner);record.putInt("x",coast.getX());record.putInt("z",coast.getZ());record.putString("maskSha256",digest);record.putLong("revision",store.revision());com.millenairekingdoms.history.HistoryFiles.write(marker,record);
            var metrics=view.getCompound("metrics");System.out.println("GEOGRAPHY_PROGRESSIVE_COAST first_display_ready_ms="+first[0]/1_000_000.0+" available_viewport_ms="+metrics.getLong("viewportCompleteNanos")/1_000_000.0+" warm_view_tiles="+warm.size()+" snapshot_hits="+metrics.getLong("snapshotHits")+" snapshot_misses="+metrics.getLong("snapshotMisses")+" main_total_ms="+metrics.getLong("mainNanos")/1_000_000.0+" worst_main_ms="+metrics.getLong("worstMainNanos")/1_000_000.0+" captured_columns="+captured+" loaded="+before+" forced="+forced+" mask_sha256="+digest+" graphics_verified=false");
        });
    }

    @GameTest(templateNamespace=NS,template="empty",batch="geography_alpha2_compat",timeoutTicks=1200)
    public static void preservedAlpha2CacheHydratesInViewportWithoutRescanningOrRewritingOldBytes(GameTestHelper h)throws Exception{
        var level=GeographyGameTests.noise(h);var owner=UUID.fromString("cfad7909-521a-4ea7-959d-5aa6bb09e7cc");var directory=GeographyService.directory(level,owner);
        var module=GeographyProgressiveGameTests.class;com.google.gson.JsonObject manifest;
        try(var input=module.getResourceAsStream("/fixtures/geography-alpha2/manifest.json")){if(input==null)throw new IllegalStateException("Missing original cache fixture");manifest=com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(input,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();}
        java.nio.file.Files.createDirectories(directory);for(var value:manifest.getAsJsonArray("files")){var file=value.getAsJsonObject();String name=file.get("name").getAsString();var target=directory.resolve(name);if(!java.nio.file.Files.exists(target))try(var input=module.getResourceAsStream("/fixtures/geography-alpha2/"+name)){java.nio.file.Files.copy(Objects.requireNonNull(input),target);}}
        var observer=new net.neoforged.neoforge.common.util.FakePlayer(level,new com.mojang.authlib.GameProfile(owner,"Preserved alpha2"));observer.setPos(0,256,0);
        var client=new GeographySnapshot();client.clear(level.dimension().location().toString());var viewport=GeographyViewport.around(345,79,48);client.viewport(viewport);var connection=UUID.randomUUID();long started=System.nanoTime();
        h.succeedWhen(()->{
            int loaded=level.getChunkSource().getLoadedChunksCount(),forced=level.getForcedChunks().size();var view=GeographyView.build(observer,ChronicleRequestPayload.geography(connection,level.getGameTime(),client.after(),client.through(),viewport,client.stream()));client.accept(view);
            h.assertTrue(loaded==level.getChunkSource().getLoadedChunksCount() && forced==level.getForcedChunks().size(),"Cached viewport hydration is read-only and cannot load a remote chunk");
            h.assertTrue(client.at(345,79)==GeographyTile.OCEAN && client.availableComplete(),"Await the already authorized original alpha2 coast; irrelevant old-cache tiles do not hold its viewport");
            h.assertTrue(digest(client.tile(GeographyTile.Position.at(345,79)).cells()).equals("ca9929a00afc1d3101963f1cbdf079ccf1e6ee96b5f0abec30e63d64317e1bfc") && view.getCompound("metrics").getLong("capturedColumns")==0,"Original acknowledged coast masks are reused exactly, without new world snapshots");
            for(var value:manifest.getAsJsonArray("files")){var file=value.getAsJsonObject();try{h.assertTrue(digest(java.nio.file.Files.readAllBytes(directory.resolve(file.get("name").getAsString()))).equals(file.get("sha256").getAsString()),"Query leaves every old acknowledged cache byte unchanged");}catch(java.io.IOException failure){throw new IllegalStateException(failure);}}
            System.out.println("GEOGRAPHY_ALPHA2_CACHE first_available_viewport_ms="+(System.nanoTime()-started)/1_000_000.0+" old_mask_exact=true terrain_columns=0 source_files_unchanged=9");
        });
    }

    @GameTest(templateNamespace=NS,template="empty")
    public static void geographyRetryNeverThrottlesThePoliticalAtlasLane(GameTestHelper h){
        var level=h.getLevel();var observer=new net.neoforged.neoforge.common.util.FakePlayer(level,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"Independent lanes"));var connection=UUID.randomUUID();
        var geo=ChronicleRequestPayload.geography(connection,1,0,Long.MAX_VALUE);com.millenairekingdoms.history.ChronicleViews.respond(observer,geo);
        var repeated=com.millenairekingdoms.history.ChronicleViews.respond(observer,geo);h.assertTrue(repeated.getInt("retryAfter")==4,"The geography lane retains its own bounded request budget");
        var political=com.millenairekingdoms.history.ChronicleViews.respond(observer,new ChronicleRequestPayload(connection,2,"ATLAS",Optional.empty(),"",0,Long.MAX_VALUE,Optional.empty(),"",Optional.empty()));
        h.assertTrue(!political.contains("retryAfter") && !political.contains("error") && political.getString("mode").equals("ATLAS"),"A geography retry cannot hold an available political map behind Loading");com.millenairekingdoms.history.ChronicleViews.forget(observer.getUUID());h.succeed();
    }

    @GameTest(templateNamespace=NS,template="empty",batch="geography_explore",timeoutTicks=2400)
    public static void coastalExplorationReusesSnapshotsAndCannotRevealOutsideThePersonalDisk(GameTestHelper h)throws Exception{
        var level=GeographyGameTests.noise(h);var coast=GeographyGameTests.coast(h,level);int tx=coast.getX()+30,tz=coast.getZ();level.getChunk(tx>>4,tz>>4);int expected=GeographyService.classifyLoadedColumn(level,tx,tz);h.assertTrue(expected!=GeographyTile.UNKNOWN,"Exploration fixture has real loaded surface data");
        var observer=new net.neoforged.neoforge.common.util.FakePlayer(level,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"Coastal explorer"));observer.setPos(coast.getX()+.5,256,coast.getZ()+.5);var connection=UUID.randomUUID();var client=new GeographySnapshot();client.clear(level.dimension().location().toString());int[] phase={0};
        // GameTest ticks are accelerated and FakePlayer does not keep a native view distance alive.
        // Pin only this fixture patch before measurement; the production sampler must not add/remove tickets.
        var fixtureTickets=new ArrayList<net.minecraft.world.level.ChunkPos>();for(int z=(coast.getZ()>>4)-1;z<=(coast.getZ()>>4)+1;z++)for(int x=(coast.getX()>>4)-1;x<=(tx>>4)+1;x++){var pos=new net.minecraft.world.level.ChunkPos(x,z);if(!level.getForcedChunks().contains(pos.toLong())){level.setChunkForced(x,z,true);fixtureTickets.add(pos);}level.getChunk(x,z);}

        h.succeedWhen(()->{
            var viewport=GeographyViewport.around(phase[0]==0?coast.getX():tx,tz,16);client.viewport(viewport);int before=level.getChunkSource().getLoadedChunksCount(),forced=level.getForcedChunks().size();
            var view=GeographyView.build(observer,ChronicleRequestPayload.geography(connection,level.getGameTime(),client.after(),client.through(),viewport,client.stream()));client.accept(view);GeographyService.observePlayers(level.getServer(),List.of(observer));
            h.assertTrue(before==level.getChunkSource().getLoadedChunksCount() && forced==level.getForcedChunks().size(),"Moving/panning the actual coast sampler never loads or forces a chunk");
            if(phase[0]==0){h.assertTrue(client.at(coast.getX(),coast.getZ())==GeographyTile.OCEAN,"Await initial observed coast");observer.setPos(coast.getX()+16.5,256,coast.getZ()+.5);phase[0]=1;h.assertTrue(false,"Continue along the real coast using cached snapshots");}
            h.assertTrue(client.at(tx,tz)==expected && view.getCompound("metrics").getLong("snapshotHits")>0,"New view becomes available with snapshot reuse: actual="+client.at(tx,tz)+" expected="+expected+" hits="+view.getCompound("metrics").getLong("snapshotHits"));
            h.assertTrue(client.at(observer.getBlockX()+GeographyService.RADIUS+1,tz)==GeographyTile.UNKNOWN,"Even a loaded shared snapshot cannot reveal a cell outside both authorized observation disks");
            for(var ticket:fixtureTickets)level.setChunkForced(ticket.x,ticket.z,false);
            System.out.println("GEOGRAPHY_COASTAL_EXPLORATION snapshot_hits="+view.getCompound("metrics").getLong("snapshotHits")+" misses="+view.getCompound("metrics").getLong("snapshotMisses")+" hit_rate="+view.getCompound("metrics").getDouble("snapshotHitRate")+" unauthorized_cells=0 forced_added=0");
        });
    }
}
