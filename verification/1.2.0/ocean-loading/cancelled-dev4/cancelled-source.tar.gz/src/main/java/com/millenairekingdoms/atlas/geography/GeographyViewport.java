package com.millenairekingdoms.atlas.geography;

/** Read-only priority hint. Bounds never authorize observations or cause a chunk request. */
public record GeographyViewport(int minX,int minZ,int maxX,int maxZ) {
    public GeographyViewport {
        if(minX>maxX || minZ>maxZ || minX< -29999983 || minZ< -29999983 || maxX>29999983 || maxZ>29999983)
            throw new IllegalArgumentException("Invalid geography priority viewport");
    }
    public static GeographyViewport around(int x,int z,int radius){return new GeographyViewport(Math.max(-29999983,x-radius),Math.max(-29999983,z-radius),Math.min(29999983,x+radius),Math.min(29999983,z+radius));}
    public static GeographyViewport from(GeographyRaster.View view){return new GeographyViewport(clamp(view.worldX(0)),clamp(view.worldZ(0)),clamp(view.worldX(view.width())),clamp(view.worldZ(view.height())));}
    private static int clamp(double value){return (int)Math.max(-29999983,Math.min(29999983,Math.floor(value)));}
    public boolean contains(int x,int z){return x>=minX && x<=maxX && z>=minZ && z<=maxZ;}
    public boolean intersects(GeographyTile.Position tile){return tile.blockX()<=maxX && tile.blockX()+31>=minX && tile.blockZ()<=maxZ && tile.blockZ()+31>=minZ;}
    public boolean intersectsChunk(int x,int z){return x*16L<=maxX && x*16L+15>=minX && z*16L<=maxZ && z*16L+15>=minZ;}
    public long distance(int x,int z){long dx=x<minX?(long)minX-x:x>maxX?(long)x-maxX:0,dz=z<minZ?(long)minZ-z:z>maxZ?(long)z-maxZ:0;return dx*dx+dz*dz;}
}
