package com.millenairekingdoms.atlas.geography;

import java.util.*;

/** Validated display observations, with an independent ephemeral stream. Never a durable/gameplay ledger. */
public final class GeographyWorkingSet {
    private final UUID epoch=UUID.randomUUID();
    private final Map<GeographyTile.Position,GeographyTile> tiles=new HashMap<>();
    private final NavigableMap<Long,GeographyTile> updates=new TreeMap<>();
    private long revision;
    public UUID epoch(){return epoch;}
    public long revision(){return revision;}
    public int size(){return tiles.size();}
    public GeographyTile tile(GeographyTile.Position position){return tiles.get(position);}
    public byte[] cells(GeographyTile.Position position){var tile=tiles.get(position);return tile==null?new byte[GeographyTile.BYTES]:tile.cells();}
    public boolean publish(GeographyTile.Position position,byte[] incoming,boolean fresh){
        if(incoming==null || incoming.length!=GeographyTile.BYTES)throw new IllegalArgumentException("Invalid observed mask");
        var old=tiles.get(position);if(old==null && tiles.size()>=GeographyStore.MAX_TILES)return false;
        byte[] merged=old==null?new byte[GeographyTile.BYTES]:old.cells();
        for(int z=0;z<32;z++)for(int x=0;x<32;x++){int value=GeographyTile.get(incoming,x,z);if(value!=0 && (fresh || GeographyTile.get(merged,x,z)==0))GeographyTile.set(merged,x,z,value);}
        if(old!=null && Arrays.equals(old.cells(),merged) || old==null && Arrays.equals(merged,new byte[GeographyTile.BYTES]))return false;
        if(revision==Long.MAX_VALUE)throw new IllegalStateException("Display stream exhausted");
        var tile=new GeographyTile(position,++revision,merged);if(old!=null)updates.remove(old.revision());tiles.put(position,tile);updates.put(revision,tile);return true;
    }
    public GeographyStore.Page page(long after,long through,GeographyViewport viewport){
        if(after<0 || through<after)throw new IllegalArgumentException("Invalid display revision window");
        long high=Math.min(through,revision);if(after>revision)return new GeographyStore.Page(List.of(),revision,revision,false,true);
        if(after>=high)return new GeographyStore.Page(List.of(),high,high,false,false);
        var selected=updates.subMap(after,false,high,true).values().stream().filter(t->viewport==null || viewport.intersects(t.position())).limit(GeographyStore.PAGE_SIZE+1L).toList();
        boolean more=selected.size()>GeographyStore.PAGE_SIZE;var page=selected.stream().limit(GeographyStore.PAGE_SIZE).toList();return new GeographyStore.Page(page,high,more?page.getLast().revision():high,more,false);
    }
}
