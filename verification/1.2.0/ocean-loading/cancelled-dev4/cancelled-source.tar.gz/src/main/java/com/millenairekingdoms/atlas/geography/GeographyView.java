package com.millenairekingdoms.atlas.geography;

import com.millenairekingdoms.history.ChronicleViews;
import com.millenairekingdoms.network.ChronicleRequestPayload;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerPlayer;

/** Only the connection's current dimension and observed geography. A client never supplies scan coordinates. */
public final class GeographyView {
    private GeographyView(){}
    public static CompoundTag build(ServerPlayer player,ChronicleRequestPayload request){
        return GeographyService.view(player,request);
    }
}
