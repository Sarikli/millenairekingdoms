package com.millenairekingdoms.atlas.geography;

import java.util.Objects;

/** Independent bounded request lane: retries/timeouts never suspend political/history traffic. */
public final class GeographyPoller {
    public static final int INTERVAL=4,TIMEOUT=40;
    private GeographyViewport viewport;private String dimension="";private long pending=-1,sent=-100,next;
    public boolean viewport(GeographyViewport wanted,String current,long tick){
        if(Objects.equals(viewport,wanted) && dimension.equals(current))return false;
        viewport=wanted;dimension=current;pending=-1;next=Math.min(next,tick);return true;
    }
    public boolean due(long tick){if(pending>=0 && tick-sent>=TIMEOUT)pending=-1;return pending<0 && tick>=next && tick-sent>=INTERVAL;}
    public void sent(long serial,long tick){pending=serial;sent=tick;next=tick+INTERVAL;}
    public boolean accept(long serial){if(pending!=serial)return false;pending=-1;return true;}
    public void retry(long tick,int delay){next=tick+Math.max(INTERVAL,Math.min(TIMEOUT,delay));}
    public void wake(long tick){next=Math.min(next,tick);}
    public void pause(){pending=-1;}
}
