package com.millenairekingdoms.atlas.geography;

import com.mojang.logging.LogUtils;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.core.BlockPos;
import net.minecraft.core.QuartPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Progressive display observations. Only immutable snapshots cross threads; the durable store has one I/O owner. */
public final class GeographyService {
    public static final int RADIUS=48,MAX_SESSIONS=16,COLUMNS_PER_PLAYER=64,INTERVAL=20;
    public static final int COLUMNS_PER_INTERVAL=1024,MAX_PENDING_WRITES=4,MAX_PROCESSING=2,MAX_DIRTY=64,RAW_CACHE=256;
    public static final int COAST_PROBE_DISTANCE=32,COASTAL_CANDIDATE=4;
    public static final long SOFT_INTERVAL_NANOS=2_000_000L;
    private static final AtomicInteger PENDING_WRITES=new AtomicInteger(),PROCESSING=new AtomicInteger();
    private static final ExecutorService MASK_IO=Executors.newSingleThreadExecutor(task->{var t=new Thread(task,"Kingdoms geography writer");t.setDaemon(true);return t;});
    private static final ExecutorService MASK_CPU=Executors.newSingleThreadExecutor(task->{var t=new Thread(task,"Kingdoms geography processor");t.setDaemon(true);return t;});
    public static final class Loading extends RuntimeException {private Loading(){super("Durable geography worker pending; display observations remain available");}}
    public static final class Capacity extends RuntimeException {private Capacity(){super("Geography sessions pinned at capacity; cached display remains available");}}
    private record Owner(UUID player,String dimension){}
    private record Chunk(int x,int z) {long key(){return (long)x<<32 ^ (z&0xffffffffL);}static Chunk at(int x,int z){return new Chunk(x>>4,z>>4);}}
    private record RawKey(String dimension,Chunk chunk){}
    private static final class Raw {
        final byte[] cells;final java.lang.ref.WeakReference<Object> chunkIdentity;final long version;long tick;
        Raw(byte[] cells,Object identity,long version,long tick){this.cells=cells;chunkIdentity=new java.lang.ref.WeakReference<>(identity);this.version=version;this.tick=tick;}
    }
    private record Seen(Map<Chunk,Long> fingerprint,BitSet covered){}
    private record Processed(Chunk chunk,Map<Chunk,Long> fingerprint,BitSet coverage,Map<GeographyTile.Position,byte[]> masks,Set<Chunk> missing){}
    private static final class Backend {
        final GeographyStore store;final Set<GeographyTile.Position> unread;
        Backend(Path path,UUID owner,String dimension){store=new GeographyStore(path,owner,dimension);unread=new HashSet<>(store.positions());}
    }
    private record DiskResult(List<GeographyTile> tiles,long revision,int remaining,int remainingVisible,GeographyViewport viewport,Map<GeographyTile.Position,byte[]> sent,String thread){}
    private static final class Session {
        final Path path;final UUID owner;final String dimension;final GeographyWorkingSet visible=new GeographyWorkingSet();
        final Map<GeographyTile.Position,byte[]> dirty=new LinkedHashMap<>();
        final ArrayDeque<GeographyTile> hydrated=new ArrayDeque<>();UUID uiSession;
        final LinkedHashMap<Chunk,Seen> seen=new LinkedHashMap<>(16,.75f,true){protected boolean removeEldestEntry(Map.Entry<Chunk,Seen> e){return size()>128;}};
        final LinkedHashSet<Chunk> supports=new LinkedHashSet<>();final Set<Chunk> changed=new HashSet<>();boolean changedAll;
        Backend backend;CompletableFuture<Backend> loading;CompletableFuture<DiskResult> saving;CompletableFuture<Processed> processing;
        GeographyViewport viewport;long activeUntil,lastRequest,opened=System.nanoTime(),firstReady=-1,complete=-1,durable,mainNanos,worstMain,hits,misses,captured,processed;
        final Set<Chunk> done=new HashSet<>();int sampleX=Integer.MIN_VALUE,sampleZ,planCursor;long refreshed,terrainEpoch,processingEpoch;
        int unread=1,unreadVisible=1,cursor;String diskError="",writer="";long warned=Long.MIN_VALUE;
        Session(Path path,UUID owner,String dimension){this.path=path;this.owner=owner;this.dimension=dimension;}
        boolean pinned(){return loading!=null || saving!=null || processing!=null || !dirty.isEmpty() || !hydrated.isEmpty();}
    }
    private static final class State {
        int rotation,diskRotation;long sequence,mainTotal,worstMain,lastMain,queryTotal,worstQuery;
        final LinkedHashMap<Owner,Session> sessions=new LinkedHashMap<>(16,.75f,true);
        final LinkedHashMap<RawKey,Raw> raw=new LinkedHashMap<>(16,.75f,true){protected boolean removeEldestEntry(Map.Entry<RawKey,Raw> e){return size()>RAW_CACHE;}};
    }
    private static final Map<MinecraftServer,State> STATES=new WeakHashMap<>();
    private GeographyService(){}
    public static Path directory(ServerLevel level,UUID player){return DimensionType.getStorageFolder(level.dimension(),level.getServer().getWorldPath(LevelResource.ROOT)).resolve("data/millenairekingdoms/geography").resolve(player.toString());}
    private static Session session(ServerPlayer player){return session(player,true);}
    private static Session session(ServerPlayer player,boolean allowActiveEviction){
        var level=player.serverLevel();if(!level.getServer().isSameThread())throw new IllegalStateException("Geography requires server thread");
        var state=STATES.computeIfAbsent(level.getServer(),unused->new State());var key=new Owner(player.getUUID(),level.dimension().location().toString());var s=state.sessions.get(key);
        if(s!=null)return s;
        if(state.sessions.size()>=MAX_SESSIONS){var iterator=state.sessions.entrySet().iterator();boolean evicted=false;while(iterator.hasNext()){var candidate=iterator.next().getValue();pump(candidate);if(!candidate.pinned() && (allowActiveEviction || candidate.activeUntil<level.getServer().getTickCount())){iterator.remove();evicted=true;break;}}if(!evicted)throw new Capacity();}
        s=new Session(directory(level,player.getUUID()),player.getUUID(),key.dimension());s.cursor=(int)Math.floorMod(++state.sequence*0x9e3779b97f4a7c15L,(long)97*97);state.sessions.put(key,s);return s;
    }
    private static boolean reserve(AtomicInteger counter,int maximum){for(;;){int count=counter.get();if(count>=maximum)return false;if(counter.compareAndSet(count,count+1))return true;}}
    private static <T> CompletableFuture<T> io(java.util.function.Supplier<T> task){
        if(!reserve(PENDING_WRITES,MAX_PENDING_WRITES))return null;
        try{return CompletableFuture.supplyAsync(()->{try{return task.get();}finally{PENDING_WRITES.decrementAndGet();}},MASK_IO);}catch(RuntimeException rejected){PENDING_WRITES.decrementAndGet();throw rejected;}
    }
    private static void fail(Session s,RuntimeException failure){s.diskError=String.valueOf(failure.getMessage());if(s.warned==Long.MIN_VALUE){s.warned=0;LogUtils.getLogger().warn("[Kingdoms] Geography persistence unavailable; prior durable files preserved, valid display observations retained: {}",s.diskError);}}
    private static void publish(Session s,Map<GeographyTile.Position,byte[]> masks,boolean fresh){
        masks.forEach((position,cells)->{if(s.visible.publish(position,cells,fresh)){if(fresh)s.dirty.put(position,s.visible.cells(position));if(s.firstReady<0 && (s.viewport==null || s.viewport.intersects(position)))s.firstReady=System.nanoTime()-s.opened;}});
    }
    private static void pump(Session s){
        if(s.processing!=null && s.processing.isDone()){
            try{var result=s.processing.join();publish(s,result.masks(),true);s.seen.put(result.chunk(),new Seen(result.fingerprint(),result.coverage()));result.missing().stream().limit(Math.max(0,64-s.supports.size())).forEach(s.supports::add);if(result.missing().isEmpty() && s.processingEpoch==s.terrainEpoch)s.done.add(result.chunk());s.processed++;}
            catch(CompletionException failure){LogUtils.getLogger().warn("[Kingdoms] Geography snapshot rejected",failure);}
            s.processing=null;
        }
        if(s.loading!=null && s.loading.isDone()){
            try{s.backend=s.loading.join();s.durable=s.backend.store.revision();s.unread=s.backend.unread.size();s.unreadVisible=s.unread;}catch(CompletionException failure){fail(s,failure);}s.loading=null;
        }
        if(s.saving!=null && s.saving.isDone()){
            try{var result=s.saving.join();s.durable=result.revision();s.unread=result.remaining();s.writer=result.thread();s.hydrated.addAll(result.tiles());s.unreadVisible=Objects.equals(s.viewport,result.viewport())?result.remainingVisible():s.unread==0?0:1;result.sent().forEach((position,cells)->{if(s.dirty.get(position)==cells)s.dirty.remove(position);});}
            catch(CompletionException failure){fail(s,failure);}s.saving=null;
        }
        var restored=new LinkedHashMap<GeographyTile.Position,byte[]>();for(int n=0;n<8 && !s.hydrated.isEmpty();n++){var tile=s.hydrated.remove();restored.put(tile.position(),tile.cells());}publish(s,restored,false);
    }
    private static void scheduleDisk(Session s){
        if(!s.diskError.isEmpty() || s.saving!=null || s.loading!=null || !s.hydrated.isEmpty())return;
        if(s.backend==null){Path path=s.path;UUID owner=s.owner;String dimension=s.dimension;s.loading=io(()->new Backend(path,owner,dimension));return;}
        if(s.dirty.isEmpty() && (s.unread==0 || s.unreadVisible==0))return;
        var sent=new LinkedHashMap<GeographyTile.Position,byte[]>();s.dirty.entrySet().stream().limit(GeographyStore.MAX_BATCH).forEach(e->sent.put(e.getKey(),e.getValue()));
        var backend=s.backend;var viewport=s.viewport;
        s.saving=io(()->{
            var merged=new LinkedHashMap<GeographyTile.Position,byte[]>();sent.forEach((position,cells)->{var bytes=backend.store.cells(position);for(int z=0;z<32;z++)for(int x=0;x<32;x++){int value=GeographyTile.get(cells,x,z);if(value!=0)GeographyTile.set(bytes,x,z,value);}merged.put(position,bytes);});
            backend.store.commit(merged);
            var result=new LinkedHashMap<GeographyTile.Position,GeographyTile>();for(var position:sent.keySet()){var tile=backend.store.observed(position);if(tile!=null)result.put(position,tile);backend.unread.remove(position);}
            var ordered=backend.unread.stream().filter(p->viewport==null || viewport.intersects(p)).sorted(Comparator.comparingLong((GeographyTile.Position p)->viewport==null?0:viewport.distance(p.blockX()+16,p.blockZ()+16)).thenComparingInt(GeographyTile.Position::x).thenComparingInt(GeographyTile.Position::z)).limit(GeographyStore.PAGE_SIZE-result.size()).toList();
            for(var position:ordered){result.put(position,backend.store.observed(position));backend.unread.remove(position);}
            return new DiskResult(List.copyOf(result.values()),backend.store.revision(),backend.unread.size(),(int)backend.unread.stream().filter(p->viewport==null || viewport.intersects(p)).count(),viewport,sent,Thread.currentThread().getName());
        });
    }
    /** Query cached display data only. A viewport is a priority hint, never discovery authority. */
    public static net.minecraft.nbt.CompoundTag view(ServerPlayer player,com.millenairekingdoms.network.ChronicleRequestPayload request){
        long queryStarted=System.nanoTime();var response=com.millenairekingdoms.history.ChronicleViews.header(player,request);var s=session(player);pump(s);long tick=player.serverLevel().getServer().getTickCount();
        var viewport=request.viewport().orElse(null);if(!Objects.equals(s.viewport,viewport) || !request.session().equals(s.uiSession) || tick-s.lastRequest>40){s.opened=System.nanoTime();s.firstReady=s.visible.page(0,Long.MAX_VALUE,viewport).tiles().isEmpty()?-1:0;s.complete=-1;s.done.clear();s.planCursor=0;s.unreadVisible=s.unread==0?0:1;}
        s.uiSession=request.session();s.viewport=viewport;s.lastRequest=tick;s.activeUntil=tick+40;scheduleDisk(s);
        var page=s.visible.page(request.fromDay(),request.toDay(),viewport);boolean streamChanged=request.stream().isPresent() && !request.stream().get().equals(s.visible.epoch());
        response.putUUID("stream",s.visible.epoch());response.putLong("durableRevision",s.durable);response.putBoolean("pendingDisk",s.loading!=null || s.saving!=null || !s.dirty.isEmpty());response.putBoolean("persistenceUnavailable",!s.diskError.isEmpty());
        response.putLong("watermark",page.watermark());response.putLong("nextRevision",streamChanged?page.watermark():page.next());response.putBoolean("more",!streamChanged && page.more());response.putBoolean("reset",streamChanged || page.reset());
        var list=new net.minecraft.nbt.ListTag();if(!streamChanged && !page.reset())for(var tile:page.tiles()){var row=new net.minecraft.nbt.CompoundTag();row.putInt("x",tile.position().x());row.putInt("z",tile.position().z());row.putLong("revision",tile.revision());row.putByteArray("cells",tile.cells());list.add(row);}response.put("geography",list);
        var current=player.serverLevel().getChunkSource().getChunkNow(player.getBlockX()>>4,player.getBlockZ()>>4);
        boolean canObserve=current!=null && player.serverLevel().canSeeSky(player.blockPosition()) && (viewport==null || viewport.distance(player.getBlockX(),player.getBlockZ())<=(long)RADIUS*RADIUS);
        if(!canObserve && s.unread==0 && s.loading==null && s.complete<0)s.complete=System.nanoTime()-s.opened;
        boolean pending=s.processing!=null || !s.supports.isEmpty() || canObserve && s.complete<0 || s.diskError.isEmpty() && (s.loading!=null || s.unreadVisible>0) || !s.hydrated.isEmpty();response.putBoolean("pendingSamples",pending);
        var metrics=new net.minecraft.nbt.CompoundTag();metrics.putLong("firstReadyNanos",s.firstReady);metrics.putLong("viewportCompleteNanos",s.complete);metrics.putLong("snapshotHits",s.hits);metrics.putLong("snapshotMisses",s.misses);metrics.putDouble("snapshotHitRate",s.hits+s.misses==0?1:s.hits/(double)(s.hits+s.misses));metrics.putLong("mainNanos",s.mainNanos);metrics.putLong("worstMainNanos",s.worstMain);metrics.putLong("capturedColumns",s.captured);metrics.putLong("processedChunks",s.processed);var state=STATES.get(player.serverLevel().getServer());metrics.putLong("serverMainTotalNanos",state.mainTotal);metrics.putLong("serverWorstMainNanos",state.worstMain);metrics.putLong("serverLastMainNanos",state.lastMain);long queryNanos=System.nanoTime()-queryStarted;state.queryTotal+=queryNanos;state.worstQuery=Math.max(state.worstQuery,queryNanos);metrics.putLong("queryNanos",queryNanos);metrics.putLong("serverQueryTotalNanos",state.queryTotal);metrics.putLong("serverWorstQueryNanos",state.worstQuery);response.put("metrics",metrics);return response;
    }
    public static void onTick(ServerTickEvent.Post event){observePlayers(event.getServer(),event.getServer().getPlayerList().getPlayers());}
    public static int observePlayers(MinecraftServer server,List<ServerPlayer> players){
        if(!server.isSameThread())throw new IllegalStateException("Geography observations require server thread");
        long started=System.nanoTime();var state=STATES.computeIfAbsent(server,unused->new State());var ordered=new ArrayList<>(state.sessions.values());for(var s:ordered)pump(s);for(int n=0;n<ordered.size();n++)scheduleDisk(ordered.get(Math.floorMod(state.diskRotation+n,ordered.size())));state.diskRotation++;if(players.isEmpty()){finish(state,started);return 0;}
        long deadline=started+SOFT_INTERVAL_NANOS;int reads=0,processed=0;
        for(int n=0;n<players.size() && reads<COLUMNS_PER_INTERVAL;n++){
            if(n>0 && System.nanoTime()>=deadline)break;var player=players.get(Math.floorMod(state.rotation+n,players.size()));processed++;
            Session s=state.sessions.get(new Owner(player.getUUID(),player.serverLevel().dimension().location().toString()));
            if(s==null){if(server.getTickCount()%INTERVAL!=0)continue;try{s=session(player,false);}catch(Loading|Capacity busy){continue;}}
            if(server.getTickCount()>s.activeUntil && server.getTickCount()%INTERVAL!=0)continue;
            long one=System.nanoTime();reads+=sample(state,s,player,deadline,COLUMNS_PER_INTERVAL-reads);long elapsed=System.nanoTime()-one;s.mainNanos+=elapsed;s.worstMain=Math.max(s.worstMain,elapsed);
        }
        state.rotation=Math.floorMod(state.rotation+processed,players.size());finish(state,started);return reads;
    }
    private static void finish(State state,long started){state.lastMain=System.nanoTime()-started;state.mainTotal+=state.lastMain;state.worstMain=Math.max(state.worstMain,state.lastMain);}
    private static Raw raw(State state,Session s,ServerLevel level,Chunk key,long tick,long deadline,int[] budget){
        var chunk=level.getChunkSource().getChunkNow(key.x(),key.z());if(chunk==null || !chunk.hasPrimedHeightmap(Heightmap.Types.WORLD_SURFACE))return null;
        var cacheKey=new RawKey(s.dimension,key);var old=state.raw.get(cacheKey);
        if(old!=null && old.chunkIdentity.get()==chunk && tick-old.tick<200){s.hits++;return old;}
        // One complete immutable 16x16 snapshot; never split a column or retain a mutable chunk in a worker.
        if(budget[0]<256 || budget[0]<COLUMNS_PER_INTERVAL && System.nanoTime()>=deadline)return null;
        var cells=new byte[256];for(int z=0;z<16;z++)for(int x=0;x<16;x++)cells[x+z*16]=(byte)rawLoadedColumn(level,key.x()*16+x,key.z()*16+z);
        budget[0]-=256;s.captured+=256;s.misses++;
        var snapshot=new Raw(cells,chunk,old!=null && old.chunkIdentity.get()==chunk && Arrays.equals(old.cells,cells)?old.version:++state.sequence,tick);state.raw.put(cacheKey,snapshot);return snapshot;
    }
    private static int sample(State state,Session s,ServerPlayer player,long deadline,int limit){
        var level=player.serverLevel();long tick=level.getServer().getTickCount();var current=level.getChunkSource().getChunkNow(player.getBlockX()>>4,player.getBlockZ()>>4);
        if(current==null || !level.canSeeSky(player.blockPosition()) || s.dirty.size()>=MAX_DIRTY)return 0;
        int[] budget={limit};
        // Supports belong only to a previously authorized primary snapshot; they are never themselves published.
        var iterator=s.supports.iterator();while(iterator.hasNext() && budget[0]>=256 && System.nanoTime()<deadline){var key=iterator.next();raw(state,s,level,key,tick,deadline,budget);iterator.remove();}
        if(s.processing!=null || PROCESSING.get()>=MAX_PROCESSING)return limit-budget[0];
        int px=player.getBlockX(),pz=player.getBlockZ();
        if(s.changedAll){s.done.clear();s.seen.clear();s.changedAll=false;}else if(!s.changed.isEmpty()){s.done.removeIf(c->s.changed.stream().anyMatch(changed->Math.abs(c.x()-changed.x())<=2 && Math.abs(c.z()-changed.z())<=2));s.seen.keySet().removeIf(c->s.changed.stream().anyMatch(changed->Math.abs(c.x()-changed.x())<=2 && Math.abs(c.z()-changed.z())<=2));}s.changed.clear();
        if(px!=s.sampleX || pz!=s.sampleZ || tick-s.refreshed>=200){s.done.clear();s.sampleX=px;s.sampleZ=pz;s.refreshed=tick;s.planCursor=0;}
        var candidates=new ArrayList<Chunk>();for(int z=(pz-RADIUS)>>4;z<=(pz+RADIUS)>>4;z++)for(int x=(px-RADIUS)>>4;x<=(px+RADIUS)>>4;x++)candidates.add(new Chunk(x,z));
        candidates.sort(Comparator.comparing((Chunk c)->s.viewport!=null && !s.viewport.intersectsChunk(c.x(),c.z())).thenComparingLong(c->s.viewport==null?0:s.viewport.distance(c.x()*16+8,c.z()*16+8)).thenComparingLong(c->{long dx=c.x()*16L+8-px,dz=c.z()*16L+8-pz;return dx*dx+dz*dz;}));
        boolean pending=false;
        for(int offset=0;offset<candidates.size();offset++){var key=candidates.get((s.planCursor+offset)%candidates.size());
            if(s.done.contains(key)){s.hits++;continue;}
            if(budget[0]<COLUMNS_PER_INTERVAL && System.nanoTime()>=deadline){pending=true;break;}
            var coverage=new BitSet(256);for(int z=0;z<16;z++)for(int x=0;x<16;x++){long dx=key.x()*16L+x-px,dz=key.z()*16L+z-pz;if(dx*dx+dz*dz<=RADIUS*RADIUS && Math.abs(key.x()*16L+x)<=29999983 && Math.abs(key.z()*16L+z)<=29999983)coverage.set(x+z*16);}
            if(coverage.isEmpty()){s.done.add(key);continue;}var primary=raw(state,s,level,key,tick,deadline,budget);if(primary==null){if(level.getChunkSource().getChunkNow(key.x(),key.z())!=null)pending=true;else s.done.add(key);continue;}
            var context=new HashMap<Chunk,byte[]>();var fingerprint=new HashMap<Chunk,Long>();
            for(int dz=-2;dz<=2;dz++)for(int dx=-2;dx<=2;dx++){var neighbor=new Chunk(key.x()+dx,key.z()+dz);var cached=state.raw.get(new RawKey(s.dimension,neighbor));var loaded=level.getChunkSource().getChunkNow(neighbor.x(),neighbor.z());if(cached!=null && cached.chunkIdentity.get()==loaded && tick-cached.tick<200){context.put(neighbor,cached.cells);fingerprint.put(neighbor,cached.version);}else if(loaded==null){context.put(neighbor,new byte[256]);fingerprint.put(neighbor,0L);}}
            var seen=s.seen.get(key);if(seen!=null && seen.fingerprint().equals(fingerprint)){var extra=(BitSet)coverage.clone();extra.andNot(seen.covered());if(extra.isEmpty()){s.done.add(key);continue;}}
            pending=true;s.planCursor=(s.planCursor+offset+1)%candidates.size();if(!reserve(PROCESSING,MAX_PROCESSING))break;var stamp=Map.copyOf(fingerprint);var captured=Map.copyOf(context);var allowed=(BitSet)coverage.clone();
            s.processingEpoch=s.terrainEpoch;try{s.processing=CompletableFuture.supplyAsync(()->{try{return process(key,stamp,allowed,captured);}finally{PROCESSING.decrementAndGet();}},MASK_CPU);}catch(RuntimeException rejected){PROCESSING.decrementAndGet();throw rejected;}break;
        }
        boolean viewportDone=candidates.stream().filter(c->s.viewport==null || s.viewport.intersectsChunk(c.x(),c.z())).allMatch(s.done::contains);
        if(viewportDone && s.complete<0)s.complete=System.nanoTime()-s.opened;
        return limit-budget[0];
    }
    private static Processed process(Chunk key,Map<Chunk,Long> fingerprint,BitSet allowed,Map<Chunk,byte[]> raw){
        var missing=new LinkedHashSet<Chunk>();var masks=new LinkedHashMap<GeographyTile.Position,byte[]>();var covered=new BitSet(256);
        for(int n=allowed.nextSetBit(0);n>=0;n=allowed.nextSetBit(n+1)){
            int x=key.x()*16+(n&15),z=key.z()*16+(n>>4);boolean[] absent={false};
            int value=classifyCoastal((sx,sz)->{var chunk=Chunk.at(sx,sz);var cells=raw.get(chunk);if(cells==null){absent[0]=true;missing.add(chunk);return GeographyTile.UNKNOWN;}return cells[(sx&15)+(sz&15)*16];},x,z);
            if(absent[0])continue;covered.set(n);if(value==GeographyTile.UNKNOWN)continue;var position=GeographyTile.Position.at(x,z);GeographyTile.set(masks.computeIfAbsent(position,unused->new byte[256]),x&31,z&31,value);
        }
        return new Processed(key,fingerprint,covered,Map.copyOf(masks),Set.copyOf(missing));
    }
    public static void onBlockChange(net.neoforged.neoforge.event.level.BlockEvent.NeighborNotifyEvent event){
        if(!(event.getLevel() instanceof ServerLevel level))return;var state=STATES.get(level.getServer());if(state==null)return;
        var changed=Chunk.at(event.getPos().getX(),event.getPos().getZ());String dimension=level.dimension().location().toString();state.raw.remove(new RawKey(dimension,changed));
        for(var session:state.sessions.values())if(session.dimension.equals(dimension) && Math.abs((long)changed.x()-(session.sampleX>>4))<=6 && Math.abs((long)changed.z()-(session.sampleZ>>4))<=6){session.terrainEpoch++;if(session.changed.size()<64)session.changed.add(changed);else session.changedAll=true;}
    }
    public static int pendingWrites(){return PENDING_WRITES.get();}
    public static int activeSessions(MinecraftServer server){var state=STATES.get(server);return state==null?0:state.sessions.size();}
    public static String lastWriteThread(ServerPlayer player){var s=session(player);pump(s);return s.writer;}
    /** Controlled synchronous validation only. Runtime sampling/querying never calls this durable-store accessor. */
    public static GeographyStore store(ServerPlayer player){
        var s=session(player);pump(s);if(s.loading!=null || s.saving!=null || !s.dirty.isEmpty())throw new Loading();
        if(s.backend==null){if(java.nio.file.Files.exists(s.path)){scheduleDisk(s);throw new Loading();}s.backend=new Backend(s.path,s.owner,s.dimension);s.unread=0;}
        return s.backend.store;
    }
    public static boolean ready(ServerPlayer player){try{store(player);return true;}catch(Loading expected){return false;}}
    /** Retains the old bounded deterministic probe for independent coast/format validation, not live scheduling. */
    public static int capture(ServerPlayer player){
        var level=player.serverLevel();var chunk=level.getChunkSource().getChunkNow(player.getBlockX()>>4,player.getBlockZ()>>4);if(chunk==null || !chunk.hasPrimedHeightmap(Heightmap.Types.WORLD_SURFACE) || !level.canSeeSky(player.blockPosition()))return 0;
        var s=session(player);var store=store(player);var observed=new LinkedHashMap<GeographyTile.Position,byte[]>();for(int n=0;n<COLUMNS_PER_PLAYER;n++){int cursor=s.cursor++%(97*97),dx=cursor%97-RADIUS,dz=cursor/97-RADIUS;if(s.cursor==97*97)s.cursor=0;if(dx*dx+dz*dz>RADIUS*RADIUS)continue;int x=player.getBlockX()+dx,z=player.getBlockZ()+dz;if(Math.abs((long)x)>29999983 || Math.abs((long)z)>29999983)continue;int value=classifyLoadedColumn(level,x,z);if(value==GeographyTile.UNKNOWN)continue;var pos=GeographyTile.Position.at(x,z);GeographyTile.set(observed.computeIfAbsent(pos,store::cells),x&31,z&31,value);}
        store.commit(observed);publish(s,observed,false);s.durable=store.revision();return COLUMNS_PER_PLAYER;
    }
    public static int captureAsync(ServerPlayer player){return observePlayers(player.serverLevel().getServer(),List.of(player));}
    public static void clear(MinecraftServer server){
        var state=STATES.remove(server);if(state==null)return;long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);
        for(var s:state.sessions.values())try{while(s.pinned() && System.nanoTime()<deadline){pump(s);scheduleDisk(s);if(s.loading!=null)s.loading.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS);if(s.processing!=null)s.processing.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS);if(s.saving!=null)s.saving.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS);if(!s.diskError.isEmpty())break;}}catch(InterruptedException interrupted){Thread.currentThread().interrupt();break;}catch(Exception failure){LogUtils.getLogger().warn("[Kingdoms] Geography shutdown incomplete; prior durable cache preserved",failure);}
    }
    /** Never creates a chunk or primes a heightmap. Ocean requires real surface water AND an ocean biome at sea level. */
    public static int classifyLoadedColumn(ServerLevel level,int x,int z){
        return classifyCoastal((px,pz)->rawLoadedColumn(level,px,pz),x,z);
    }
    /** A beach's submerged strip is sea only along a real continuous, loaded water line to an ocean seed. */
    public static int classifyCoastal(java.util.function.IntBinaryOperator source,int x,int z){
        int primary=source.applyAsInt(x,z);if(primary!=COASTAL_CANDIDATE)return primary;
        for(int direction=0;direction<4;direction++)for(int distance=1;distance<=COAST_PROBE_DISTANCE;distance++){
            int px=x+(direction==0?distance:direction==1?-distance:0),pz=z+(direction==2?distance:direction==3?-distance:0);int value=source.applyAsInt(px,pz);
            if(value==GeographyTile.OCEAN)return GeographyTile.OCEAN;
            if(value!=COASTAL_CANDIDATE)break; // Never cross land, a river/lake, height mismatch, or an unknown/unloaded column.
        }
        return GeographyTile.OTHER_WATER;
    }
    private static int rawLoadedColumn(ServerLevel level,int x,int z){
        var chunk=level.getChunkSource().getChunkNow(x>>4,z>>4);if(chunk==null || !chunk.hasPrimedHeightmap(Heightmap.Types.WORLD_SURFACE))return GeographyTile.UNKNOWN;
        int y=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,x&15,z&15);if(y<level.getMinBuildHeight() || y>=level.getMaxBuildHeight())return GeographyTile.UNKNOWN;
        var position=new BlockPos(x,y,z);var block=chunk.getBlockState(position);if(block.isAir())return GeographyTile.UNKNOWN;
        if(!block.getFluidState().is(FluidTags.WATER) || block.blocksMotion())return GeographyTile.LAND;
        if(Math.abs((long)y+1-level.getSeaLevel())>2)return GeographyTile.OTHER_WATER;
        var biome=chunk.getNoiseBiome(QuartPos.fromBlock(x),QuartPos.fromBlock(level.getSeaLevel()),QuartPos.fromBlock(z));
        if(biome.is(BiomeTags.IS_RIVER))return GeographyTile.OTHER_WATER;
        if(biome.is(BiomeTags.IS_OCEAN))return GeographyTile.OCEAN;
        return biome.is(BiomeTags.IS_BEACH)?COASTAL_CANDIDATE:GeographyTile.OTHER_WATER;
    }
}
