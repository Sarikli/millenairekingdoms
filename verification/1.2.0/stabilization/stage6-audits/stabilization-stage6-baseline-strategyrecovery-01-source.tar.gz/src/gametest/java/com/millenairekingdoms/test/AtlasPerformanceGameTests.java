package com.millenairekingdoms.test;

import com.millenairekingdoms.atlas.AtlasColors;
import com.millenairekingdoms.history.HistoryHooks;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Actual production allocator and persisted file, no graphical FPS claim or timing-based flaky pass criterion. */
@PrefixGameTestTemplate(false)
public final class AtlasPerformanceGameTests {
    @GameTest(templateNamespace="millenairekingdoms_atlas_tests",template="empty",timeoutTicks=1200)
    public static void largeColorRegistryKeepsExactIdentityAndMeasuresColdWarmCost(GameTestHelper h){
        var file=HistoryHooks.directory(h.getLevel()).resolve("color-performance-"+UUID.randomUUID()+".dat");var colors=new AtlasColors(file);var ids=new ArrayList<UUID>();for(int n=0;n<8192;n++)ids.add(new UUID(200,n));
        long start=System.nanoTime();colors.ensure(ids.subList(0,500));long fiveHundred=System.nanoTime()-start;var existing=new HashMap<UUID,Integer>();for(var id:ids.subList(0,500))existing.put(id,colors.color(id));start=System.nanoTime();colors.ensure(ids);long large=System.nanoTime()-start;start=System.nanoTime();colors.ensure(ids);long warm=System.nanoTime()-start;var reopen=new AtlasColors(file);
        h.assertTrue(existing.entrySet().stream().allMatch(e->colors.color(e.getKey())==e.getValue() && reopen.color(e.getKey())==e.getValue()),"Growing registry to8192 never changes any established political color and saved registry reopens exactly");for(var id:ids)h.assertTrue(colors.color(id)==reopen.color(id),"Every supported registered identity persists without terrain access");
        System.out.println("ATLAS_COLOR_PERFORMANCE registry500Micros="+fiveHundred/1000+" grow8192Micros="+large/1000+" unchanged8192Micros="+warm/1000+" exactPersisted=true");h.succeed();
    }
}
